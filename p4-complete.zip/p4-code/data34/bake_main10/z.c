#include <stdio.h>

void func1(){
  printf("I'm the Z version\n");
}
