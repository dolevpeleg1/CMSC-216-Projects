#include <stdio.h>
void func_10(){
  printf("Calling function func_10\n");
}
