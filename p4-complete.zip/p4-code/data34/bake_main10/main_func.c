#include <stdio.h>
#include "funcs.h"
int main(int argc, char *argv[]){
  // call various library functions
  func_01();
  func_02();
  func_03();
  func_04();
  func_05();
  func_06();
  func_07();
  func_08();
  func_09();
  func_10();
  return 0;
}
