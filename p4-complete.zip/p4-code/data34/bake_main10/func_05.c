#include <stdio.h>
void func_05(){
  printf("Calling function func_05\n");
}
