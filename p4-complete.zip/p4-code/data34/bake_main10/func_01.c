#include <stdio.h>
void func_01(){
  printf("Calling function func_01\n");
}
