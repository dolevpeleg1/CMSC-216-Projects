#include <stdio.h>
void func_06(){
  printf("Calling function func_06\n");
}
