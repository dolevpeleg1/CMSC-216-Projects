#include <stdio.h>
void func_04(){
  printf("Calling function func_04\n");
}
