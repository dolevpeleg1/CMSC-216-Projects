#include <stdio.h>
void goodbye(){
  printf("See you, space cowboy\n");
}
