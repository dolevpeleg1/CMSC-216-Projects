#include <stdio.h>
void goodbye();
int main(){
  printf("Hello world!\n");
  goodbye();
  return 0;
}
