#include <stdio.h>
void func1(){
  printf("running func1\n");
}
