#include <stdio.h>
void func1();
void func2();
int main(){
  printf("In main\n");
  func1();
  func2();
  return 0;
}
